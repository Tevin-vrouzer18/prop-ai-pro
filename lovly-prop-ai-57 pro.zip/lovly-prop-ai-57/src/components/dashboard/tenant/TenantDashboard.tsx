import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { 
  CreditCard, Wrench, FileText, MessageCircle, AlertCircle, Calendar, Home, 
  Building2, User, Phone, Shield
} from 'lucide-react';
import { TenantPaymentModal } from './TenantPaymentModal';
import { MaintenanceRequestModal } from '@/components/dashboard/maintenance/MaintenanceRequestModal';
import { MaintenanceRequestView } from './MaintenanceRequestView';
import { TenantDocuments } from './TenantDocuments';
import { UnitBrowsing } from './UnitBrowsing';
import { MyApplications } from './MyApplications';
import { ProfileEditForm } from './profile/ProfileEditForm';
import { CoTenantManagement } from './profile/CoTenantManagement';
import { PasswordChangeForm } from './profile/PasswordChangeForm';
import { SessionsManagement } from './profile/SessionsManagement';
import { PaymentMethodsManagement } from './profile/PaymentMethodsManagement';
import { MessagesSection } from './MessagesSection';
import { useMaintenanceRequests } from '@/hooks/useMaintenanceRequests';
import { useApprovedLease } from '@/hooks/useApprovedLease';
import { useApplicationStatus } from '@/hooks/useApplicationStatus';
import { supabase } from '@/integrations/supabase/client';

interface TenantDashboardProps {
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

const TenantDashboard = ({ activeTab = "overview", onTabChange }: TenantDashboardProps) => {
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showMaintenanceModal, setShowMaintenanceModal] = useState(false);
  const [showMaintenanceView, setShowMaintenanceView] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  const [rentBalance, setRentBalance] = useState(25000);
  const [maintenanceFilter, setMaintenanceFilter] = useState('all');
  const [maintenanceSearchTerm, setMaintenanceSearchTerm] = useState('');
  
  const { requests: maintenanceRequests, loading: maintenanceLoading, refetch } = useMaintenanceRequests();
  const { approvedLease, hasApprovedLease, loading: leaseLoading } = useApprovedLease();
  const { hasApprovedApplication, hasActiveApplication, loading: appStatusLoading } = useApplicationStatus();

  // Real-time updates for all tenant data
  useEffect(() => {
    const rentPaymentsChannel = supabase
      .channel('rent_payments_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'rent_payments'
        },
        (payload) => {
          console.log('Payment update:', payload);
          if (payload.eventType === 'INSERT' && payload.new.status === 'paid') {
            setRentBalance(prev => Math.max(0, prev - (payload.new.amount || 0)));
          }
          refetch();
        }
      )
      .subscribe();

    const maintenanceChannel = supabase
      .channel('maintenance_requests_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'maintenance_requests'
        },
        (payload) => {
          console.log('Maintenance request update:', payload);
          refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(rentPaymentsChannel);
      supabase.removeChannel(maintenanceChannel);
    };
  }, [refetch]);

  const mockData = {
    rentBalance,
    nextPaymentDue: '2024-02-15',
    pendingRequests: maintenanceRequests.filter(r => r.status === 'pending').length,
    profile: {
      name: 'John Doe',
      email: 'john.doe@email.com',
      phone: '+254 712 345 678',
      emergencyContact: 'Jane Doe - +254 712 345 679',
      unit: 'Apt 3B',
      leaseType: '12-month lease',
      leaseStart: '2024-01-01',
      leaseEnd: '2024-12-31',
      defaultPaymentMethod: 'M-PESA'
    }
  };

  const handlePaymentSuccess = () => {
    setRentBalance(0);
    refetch();
  };

  const handleViewRequest = (request: any) => {
    setSelectedRequest(request);
    setShowMaintenanceView(true);
  };

  // Determine if user has access to premium features
  const hasAccess = hasApprovedLease || hasApprovedApplication;

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Welcome Back</h1>
        <p className="text-muted-foreground">Here's what's happening with your rental</p>
      </div>

      {/* Tabbed Interface */}
      <Tabs value={activeTab} onValueChange={onTabChange} className="w-full">
        <TabsList className={`grid w-full ${hasApprovedLease ? 'grid-cols-6' : 'grid-cols-8'} mb-6`}>
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Home className="h-4 w-4" />
            Overview
          </TabsTrigger>
          {!hasApprovedLease && (
            <>
              <TabsTrigger value="browse-units" className="flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                Browse Units
              </TabsTrigger>
              <TabsTrigger value="my-applications" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Applications
              </TabsTrigger>
            </>
          )}
          <TabsTrigger 
            value="payments" 
            className="flex items-center gap-2"
            disabled={!hasAccess}
          >
            <CreditCard className="h-4 w-4" />
            Payments
          </TabsTrigger>
          <TabsTrigger 
            value="maintenance" 
            className="flex items-center gap-2"
            disabled={!hasAccess}
          >
            <Wrench className="h-4 w-4" />
            Maintenance
          </TabsTrigger>
          <TabsTrigger 
            value="documents" 
            className="flex items-center gap-2"
            disabled={!hasAccess}
          >
            <FileText className="h-4 w-4" />
            Documents
          </TabsTrigger>
          <TabsTrigger 
            value="messages" 
            className="flex items-center gap-2"
            disabled={!hasAccess}
          >
            <MessageCircle className="h-4 w-4" />
            Messages
          </TabsTrigger>
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            Profile
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-gradient-to-r from-primary to-primary-glow text-primary-foreground">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Current Balance</CardTitle>
                <CreditCard className="h-4 w-4" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">KES {mockData.rentBalance.toLocaleString()}</div>
                <p className="text-xs opacity-90">Due: {mockData.nextPaymentDue}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Maintenance Requests</CardTitle>
                <Wrench className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{mockData.pendingRequests}</div>
                <p className="text-xs text-muted-foreground">Active requests</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Lease Status</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {hasApprovedLease ? 'Active' : hasApprovedApplication ? 'Approved' : 'Pending'}
                </div>
                <p className="text-xs text-muted-foreground">
                  {hasApprovedLease ? 'Expires: Dec 2024' : hasApprovedApplication ? 'Awaiting lease' : 'Apply for units'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Messages</CardTitle>
                <MessageCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3</div>
                <p className="text-xs text-muted-foreground">Unread messages</p>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Quick Actions
              </CardTitle>
              <CardDescription>Common tasks and shortcuts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {!hasApprovedLease && (
                  <Button 
                    className="h-auto p-4 flex flex-col items-center gap-2" 
                    variant="outline"
                    onClick={() => onTabChange?.("browse-units")}
                  >
                    <Building2 className="h-6 w-6" />
                    <span>Browse Units</span>
                  </Button>
                )}
                {hasAccess && (
                  <>
                    <Button 
                      className="h-auto p-4 flex flex-col items-center gap-2" 
                      variant="outline"
                      onClick={() => setShowPaymentModal(true)}
                    >
                      <CreditCard className="h-6 w-6" />
                      <span>Pay Rent</span>
                    </Button>
                    <Button 
                      className="h-auto p-4 flex flex-col items-center gap-2" 
                      variant="outline"
                      onClick={() => setShowMaintenanceModal(true)}
                    >
                      <Wrench className="h-6 w-6" />
                      <span>Request Maintenance</span>
                    </Button>
                    <Button 
                      className="h-auto p-4 flex flex-col items-center gap-2" 
                      variant="outline"
                      onClick={() => onTabChange?.("documents")}
                    >
                      <FileText className="h-6 w-6" />
                      <span>View Documents</span>
                    </Button>
                    <Button 
                      className="h-auto p-4 flex flex-col items-center gap-2" 
                      variant="outline"
                      onClick={() => onTabChange?.("messages")}
                    >
                      <MessageCircle className="h-6 w-6" />
                      <span>Contact Landlord</span>
                    </Button>
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Important Notice */}
          {!hasAccess && (
            <Card className="border-warning bg-warning/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-warning">
                  <AlertCircle className="h-5 w-5" />
                  Application Required
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  To access payment, maintenance, documents, and messaging features, you need to apply for a unit and get approved by the landlord.
                </p>
              </CardContent>
            </Card>
          )}

          {hasAccess && (
            <Card className="border-warning bg-warning/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-warning">
                  <AlertCircle className="h-5 w-5" />
                  Important Notice
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  Your rent payment for February is due in 5 days. Please ensure payment is made on time to avoid late fees.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Browse Units Tab - Only show if no approved lease */}
        {!hasApprovedLease && (
          <TabsContent value="browse-units" className="space-y-6">
            <UnitBrowsing />
          </TabsContent>
        )}

        {/* My Applications Tab - Only show if no approved lease */}
        {!hasApprovedLease && (
          <TabsContent value="my-applications" className="space-y-6">
            <MyApplications />
          </TabsContent>
        )}

        {/* Payments Tab */}
        <TabsContent value="payments" className="space-y-6">
          {!hasAccess ? (
            <Card>
              <CardContent className="text-center py-8">
                <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">Access Restricted</h3>
                <p className="text-muted-foreground mb-4">
                  You need to have an approved application or active lease to access payment features.
                </p>
                <Button onClick={() => onTabChange?.("browse-units")}>
                  Browse Available Units
                </Button>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Header */}
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-semibold">Rent & Payments</h3>
                  <p className="text-muted-foreground">Manage your rent payments and history</p>
                </div>
                <Button onClick={() => setShowPaymentModal(true)}>
                  <CreditCard className="h-4 w-4 mr-2" />
                  Pay Rent
                </Button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Current Balance */}
                <Card className="bg-gradient-to-r from-primary to-primary-glow text-primary-foreground">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CreditCard className="h-5 w-5" />
                      Current Balance
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold mb-2">KES {mockData.rentBalance.toLocaleString()}</div>
                    <p className="text-sm opacity-90 mb-2">Due: {mockData.nextPaymentDue}</p>
                    <p className="text-xs opacity-75 mb-4">Late fee: KES 2,500 after due date</p>
                    <Button 
                      variant="secondary" 
                      onClick={() => setShowPaymentModal(true)}
                      className="w-full"
                    >
                      Pay Now
                    </Button>
                  </CardContent>
                </Card>

                {/* Payment History */}
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Payments</CardTitle>
                    <CardDescription>Your recent rent payment history</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div>
                          <p className="font-medium">January 2024</p>
                          <p className="text-sm text-muted-foreground">M-PESA</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">KES 25,000</p>
                          <Badge variant="secondary" className="bg-success text-success-foreground">Paid</Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </TabsContent>

        {/* Maintenance Tab */}
        <TabsContent value="maintenance" className="space-y-6">
          {!hasAccess ? (
            <Card>
              <CardContent className="text-center py-8">
                <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">Access Restricted</h3>
                <p className="text-muted-foreground mb-4">
                  You need to have an approved application or active lease to access maintenance features.
                </p>
                <Button onClick={() => onTabChange?.("browse-units")}>
                  Browse Available Units
                </Button>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Header */}
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-semibold">Maintenance Requests</h3>
                  <p className="text-muted-foreground">Submit and track maintenance requests</p>
                </div>
                <Button onClick={() => setShowMaintenanceModal(true)}>
                  <Wrench className="h-4 w-4 mr-2" />
                  New Request
                </Button>
              </div>

              {/* Emergency Contacts */}
              <Card className="border-destructive bg-destructive/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-destructive">
                    <Phone className="h-5 w-5" />
                    Emergency Contacts
                  </CardTitle>
                  <CardDescription>For urgent repairs that require immediate attention</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-destructive/10 rounded-lg flex items-center justify-center">
                        <Wrench className="h-5 w-5 text-destructive" />
                      </div>
                      <div>
                        <p className="font-medium">Emergency Maintenance</p>
                        <p className="text-sm text-muted-foreground">+254 700 123 456</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-destructive/10 rounded-lg flex items-center justify-center">
                        <Shield className="h-5 w-5 text-destructive" />
                      </div>
                      <div>
                        <p className="font-medium">Security Emergency</p>
                        <p className="text-sm text-muted-foreground">+254 700 789 012</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documents" className="space-y-6">
          {!hasAccess ? (
            <Card>
              <CardContent className="text-center py-8">
                <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">Access Restricted</h3>
                <p className="text-muted-foreground mb-4">
                  You need to have an approved application or active lease to access documents.
                </p>
                <Button onClick={() => onTabChange?.("browse-units")}>
                  Browse Available Units
                </Button>
              </CardContent>
            </Card>
          ) : (
            <TenantDocuments />
          )}
        </TabsContent>

        {/* Messages Tab */}
        <TabsContent value="messages" className="space-y-6">
          {!hasAccess ? (
            <Card>
              <CardContent className="text-center py-8">
                <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">Access Restricted</h3>
                <p className="text-muted-foreground mb-4">
                  You need to have an approved application or active lease to access messaging.
                </p>
                <Button onClick={() => onTabChange?.("browse-units")}>
                  Browse Available Units
                </Button>
              </CardContent>
            </Card>
          ) : (
            <MessagesSection />
          )}
        </TabsContent>

        {/* Profile Tab */}
        <TabsContent value="profile" className="space-y-6">
          <ProfileEditForm />
          <CoTenantManagement />
          <PaymentMethodsManagement />
          <PasswordChangeForm />
          <SessionsManagement />
        </TabsContent>
      </Tabs>

      {/* Modals */}
      <TenantPaymentModal
        open={showPaymentModal}
        onOpenChange={setShowPaymentModal}
        rentAmount={mockData.rentBalance}
        dueDate={mockData.nextPaymentDue}
        onPaymentSuccess={handlePaymentSuccess}
      />
      
      <MaintenanceRequestModal
        isOpen={showMaintenanceModal}
        onClose={() => setShowMaintenanceModal(false)}
        onSuccess={refetch}
      />
      
      <MaintenanceRequestView
        isOpen={showMaintenanceView}
        onClose={() => setShowMaintenanceView(false)}
        request={selectedRequest}
      />
    </div>
  );
};

export { TenantDashboard };