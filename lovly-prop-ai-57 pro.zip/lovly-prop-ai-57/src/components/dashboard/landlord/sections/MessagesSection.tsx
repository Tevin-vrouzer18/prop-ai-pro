import { MessageCenter } from '@/components/dashboard/messaging/MessageCenter';

export const MessagesSection = () => {
  return <MessageCenter />;
};