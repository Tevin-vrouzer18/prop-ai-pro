import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clipboard, Calendar, Package, FileText, Clock, MapPin, Wrench } from 'lucide-react';

const CaretakerDashboard = () => {
  const mockData = {
    activeWorkOrders: 7,
    completedToday: 3,
    urgentTasks: 2,
    scheduledTasks: 5,
    workOrders: [
      { id: '1', title: 'Fix Leaking Pipe - Unit 2A', priority: 'high', status: 'assigned', property: 'Building A', time: '09:00 AM' },
      { id: '2', title: 'AC Maintenance - Unit 1B', priority: 'medium', status: 'in_progress', property: 'Building A', time: '11:00 AM' },
      { id: '3', title: 'Light Fixture Replacement - Unit 3C', priority: 'low', status: 'pending', property: 'Building B', time: '02:00 PM' },
      { id: '4', title: 'Emergency Door Lock Fix - Unit 1A', priority: 'high', status: 'urgent', property: 'Building A', time: 'ASAP' },
    ],
    inventory: [
      { item: 'Light Bulbs', stock: 15, minimum: 10, status: 'good' },
      { item: 'Plumbing Fittings', stock: 5, minimum: 8, status: 'low' },
      { item: 'Paint (White)', stock: 3, minimum: 5, status: 'low' },
      { item: 'Cleaning Supplies', stock: 25, minimum: 15, status: 'good' },
    ]
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-destructive';
      case 'medium': return 'bg-warning';
      case 'low': return 'bg-success';
      default: return 'bg-muted';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'urgent': return 'bg-destructive text-destructive-foreground';
      case 'in_progress': return 'bg-primary';
      case 'assigned': return 'bg-warning';
      case 'pending': return 'bg-muted';
      default: return 'bg-muted';
    }
  };

  const getStockStatus = (current: number, minimum: number) => {
    if (current <= minimum) return 'low';
    if (current <= minimum * 1.5) return 'medium';
    return 'good';
  };

  const getStockColor = (status: string) => {
    switch (status) {
      case 'low': return 'bg-destructive';
      case 'medium': return 'bg-warning';
      case 'good': return 'bg-success';
      default: return 'bg-muted';
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Work Dashboard</h1>
        <p className="text-muted-foreground">Manage your work orders and maintenance tasks</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-primary to-primary-glow text-primary-foreground">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Orders</CardTitle>
            <Clipboard className="h-4 w-4" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockData.activeWorkOrders}</div>
            <p className="text-xs opacity-90">In progress</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed Today</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockData.completedToday}</div>
            <p className="text-xs text-muted-foreground">Tasks finished</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Urgent Tasks</CardTitle>
            <Wrench className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{mockData.urgentTasks}</div>
            <p className="text-xs text-muted-foreground">Need immediate attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Scheduled</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockData.scheduledTasks}</div>
            <p className="text-xs text-muted-foreground">Upcoming tasks</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Common work management tasks</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button className="h-auto p-4 flex flex-col items-center gap-2" variant="outline">
              <Clipboard className="h-6 w-6" />
              <span>View All Orders</span>
            </Button>
            <Button className="h-auto p-4 flex flex-col items-center gap-2" variant="outline">
              <Calendar className="h-6 w-6" />
              <span>My Schedule</span>
            </Button>
            <Button className="h-auto p-4 flex flex-col items-center gap-2" variant="outline">
              <Package className="h-6 w-6" />
              <span>Check Inventory</span>
            </Button>
            <Button className="h-auto p-4 flex flex-col items-center gap-2" variant="outline">
              <FileText className="h-6 w-6" />
              <span>Submit Report</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Work Orders and Inventory */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Work Orders */}
        <Card>
          <CardHeader>
            <CardTitle>Today's Work Orders</CardTitle>
            <CardDescription>Your assigned tasks for today</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockData.workOrders.map((order) => (
                <div key={order.id} className="flex items-start justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium text-sm">{order.title}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <MapPin className="h-3 w-3 text-muted-foreground" />
                      <p className="text-xs text-muted-foreground">{order.property}</p>
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge className={getPriorityColor(order.priority)} variant="secondary">
                        {order.priority}
                      </Badge>
                      <Badge className={getStatusColor(order.status)} variant="secondary">
                        {order.status}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{order.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Inventory Status */}
        <Card>
          <CardHeader>
            <CardTitle>Inventory Status</CardTitle>
            <CardDescription>Current stock levels</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockData.inventory.map((item, index) => {
                const stockStatus = getStockStatus(item.stock, item.minimum);
                return (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <p className="font-medium text-sm">{item.item}</p>
                      <p className="text-xs text-muted-foreground">Min: {item.minimum}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold">{item.stock}</span>
                      <Badge className={getStockColor(stockStatus)} variant="secondary">
                        {stockStatus}
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Important Notices */}
      <Card className="border-warning bg-warning/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-warning">
            <Clock className="h-5 w-5" />
            Daily Reminders
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p className="text-sm">• Building A daily inspection due at 8:00 AM</p>
            <p className="text-sm">• Emergency contact training scheduled for 3:00 PM</p>
            <p className="text-sm">• Weekly inventory check due by end of day</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export { CaretakerDashboard };