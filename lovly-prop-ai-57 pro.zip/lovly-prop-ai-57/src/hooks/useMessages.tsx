import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { toast } from 'sonner';

export interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  property_id?: string;
  unit_id?: string;
  message: string;
  read: boolean;
  created_at: string;
  updated_at: string;
  sender?: {
    id: string;
    first_name: string;
    last_name: string;
    avatar_url?: string;
    role: string;
  };
  receiver?: {
    id: string;
    first_name: string;
    last_name: string;
    avatar_url?: string;
    role: string;
  };
  property?: {
    name: string;
  };
  unit?: {
    unit_number: string;
  };
}

export interface Conversation {
  participant_id: string;
  participant_name: string;
  participant_role: string;
  participant_avatar?: string;
  last_message: string;
  last_message_time: string;
  unread_count: number;
  property_name?: string;
  unit_number?: string;
}

export const useMessages = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const { profile } = useAuth();

  const fetchMessages = async () => {
    if (!profile?.id) return;

    try {
      const { data: messagesData, error } = await supabase
        .from('messages')
        .select('*')
        .or(`sender_id.eq.${profile.id},receiver_id.eq.${profile.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Fetch user profiles separately
      const userIds = [...new Set([
        ...(messagesData || []).map(m => m.sender_id),
        ...(messagesData || []).map(m => m.receiver_id),
      ])];

      const { data: profilesData } = await supabase
        .from('profiles')
        .select('id, first_name, last_name, avatar_url, role')
        .in('id', userIds);

      const profilesMap = new Map((profilesData || []).map(p => [p.id, p]));

      const enrichedMessages = (messagesData || []).map(message => ({
        ...message,
        sender: profilesMap.get(message.sender_id),
        receiver: profilesMap.get(message.receiver_id),
      }));

      setMessages(enrichedMessages as Message[]);
    } catch (error) {
      console.error('Error fetching messages:', error);
      toast.error('Failed to load messages');
    }
  };

  const fetchConversations = async () => {
    if (!profile?.id) return;

    try {
      setLoading(true);
      
      const { data: messagesData, error } = await supabase
        .from('messages')
        .select('*')
        .or(`sender_id.eq.${profile.id},receiver_id.eq.${profile.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Fetch user profiles separately
      const userIds = [...new Set([
        ...(messagesData || []).map(m => m.sender_id),
        ...(messagesData || []).map(m => m.receiver_id),
      ])];

      const { data: profilesData } = await supabase
        .from('profiles')
        .select('id, first_name, last_name, avatar_url, role')
        .in('id', userIds);

      const profilesMap = new Map((profilesData || []).map(p => [p.id, p]));

      // Group messages by conversation
      const conversationMap = new Map<string, Conversation>();
      
      (messagesData || []).forEach((message: any) => {
        const isFromCurrentUser = message.sender_id === profile.id;
        const participantId = isFromCurrentUser ? message.receiver_id : message.sender_id;
        const participant = profilesMap.get(participantId);
        
        if (!participant) return;
        
        const existing = conversationMap.get(participantId);
        
        if (!existing || new Date(message.created_at) > new Date(existing.last_message_time)) {
          conversationMap.set(participantId, {
            participant_id: participantId,
            participant_name: `${participant.first_name} ${participant.last_name}`,
            participant_role: participant.role,
            participant_avatar: participant.avatar_url,
            last_message: message.message,
            last_message_time: message.created_at,
            unread_count: 0,
          });
        }
      });

      // Calculate unread counts
      for (const [participantId, conversation] of conversationMap) {
        const unreadCount = (messagesData || []).filter(
          (msg: any) => 
            msg.sender_id === participantId && 
            msg.receiver_id === profile.id && 
            !msg.read
        ).length;
        
        conversation.unread_count = unreadCount;
      }

      setConversations(Array.from(conversationMap.values()));
    } catch (error) {
      console.error('Error fetching conversations:', error);
      toast.error('Failed to load conversations');
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async (receiverId: string, message: string, propertyId?: string, unitId?: string) => {
    if (!profile?.id) return false;

    try {
      const { data, error } = await supabase
        .from('messages')
        .insert({
          sender_id: profile.id,
          receiver_id: receiverId,
          message,
          property_id: propertyId,
          unit_id: unitId,
        })
        .select()
        .single();

      if (error) throw error;

      toast.success('Message sent successfully!');
      await fetchMessages();
      await fetchConversations();
      return true;
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message');
      return false;
    }
  };

  const markAsRead = async (messageIds: string[]) => {
    try {
      const { error } = await supabase
        .from('messages')
        .update({ read: true })
        .in('id', messageIds);

      if (error) throw error;
      
      await fetchMessages();
      await fetchConversations();
    } catch (error) {
      console.error('Error marking messages as read:', error);
    }
  };

  const getConversationMessages = (participantId: string) => {
    return messages.filter(
      msg => 
        (msg.sender_id === profile?.id && msg.receiver_id === participantId) ||
        (msg.sender_id === participantId && msg.receiver_id === profile?.id)
    );
  };

  const getLandlordForTenant = async () => {
    if (!profile?.id || profile.role !== 'tenant') return null;

    try {
      // First try to get landlord from active lease
      const { data: leaseData, error: leaseError } = await supabase
        .from('leases')
        .select(`
          units (
            properties (
              landlord_id,
              name
            )
          )
        `)
        .eq('tenant_id', profile.id)
        .eq('status', 'active')
        .limit(1);

      if (leaseData && leaseData.length > 0) {
        const landlordId = leaseData[0]?.units?.properties?.landlord_id;
        const propertyName = leaseData[0]?.units?.properties?.name;
        
        if (landlordId) {
          const { data: landlordProfile } = await supabase
            .from('profiles')
            .select('id, first_name, last_name, avatar_url, role')
            .eq('id', landlordId)
            .single();
          
          return landlordProfile ? { ...landlordProfile, property_name: propertyName } : null;
        }
      }

      // If no active lease, try to get landlord from approved applications
      const { data: applicationData, error: appError } = await supabase
        .from('unit_applications')
        .select(`
          property_id,
          properties (
            landlord_id,
            name
          )
        `)
        .eq('tenant_id', profile.id)
        .eq('status', 'approved')
        .limit(1);

      if (applicationData && applicationData.length > 0) {
        const landlordId = applicationData[0]?.properties?.landlord_id;
        const propertyName = applicationData[0]?.properties?.name;
        
        if (landlordId) {
          const { data: landlordProfile } = await supabase
            .from('profiles')
            .select('id, first_name, last_name, avatar_url, role')
            .eq('id', landlordId)
            .single();
          
          return landlordProfile ? { ...landlordProfile, property_name: propertyName } : null;
        }
      }

      return null;
    } catch (error) {
      console.error('Error finding landlord:', error);
      return null;
    }
  };

  const getTenantsForLandlord = async () => {
    if (!profile?.id || profile.role !== 'landlord') return [];

    try {
      // Get leases for the landlord's properties with tenant info
      const { data: leaseData, error: leaseError } = await supabase
        .from('leases')
        .select(`
          tenant_id,
          units (
            unit_number,
            properties!inner (
              id,
              name,
              landlord_id
            )
          )
        `)
        .eq('units.properties.landlord_id', profile.id)
        .eq('status', 'active');

      if (leaseError) throw leaseError;

      const tenantIds = (leaseData || []).map(lease => lease.tenant_id);

      if (tenantIds.length === 0) return [];

      // Get tenant profiles with property context
      const tenantsWithContext = await Promise.all(
        (leaseData || []).map(async (lease) => {
          const { data: tenantProfile } = await supabase
            .from('profiles')
            .select('id, first_name, last_name, avatar_url, role')
            .eq('id', lease.tenant_id)
            .single();

          if (tenantProfile) {
            return {
              ...tenantProfile,
              property_name: lease.units?.properties?.name,
              unit_number: lease.units?.unit_number,
            };
          }
          return null;
        })
      );

      return tenantsWithContext.filter(Boolean);
    } catch (error) {
      console.error('Error fetching tenants:', error);
      return [];
    }
  };

  useEffect(() => {
    if (profile?.id) {
      fetchMessages();
      fetchConversations();

      // Set up real-time subscription
      const channel = supabase
        .channel('messages')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'messages',
            filter: `or(sender_id.eq.${profile.id},receiver_id.eq.${profile.id})`,
          },
          () => {
            fetchMessages();
            fetchConversations();
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [profile?.id]);

  return {
    messages,
    conversations,
    loading,
    sendMessage,
    markAsRead,
    getConversationMessages,
    getLandlordForTenant,
    getTenantsForLandlord,
    refetch: () => {
      fetchMessages();
      fetchConversations();
    },
  };
};