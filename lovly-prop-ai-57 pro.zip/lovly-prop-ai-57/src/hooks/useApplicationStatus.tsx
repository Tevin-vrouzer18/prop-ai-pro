import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

interface ApplicationStatus {
  hasApprovedApplication: boolean;
  hasActiveApplication: boolean;
  pendingApplications: number;
  approvedApplications: number;
  loading: boolean;
}

export const useApplicationStatus = (): ApplicationStatus => {
  const [status, setStatus] = useState<ApplicationStatus>({
    hasApprovedApplication: false,
    hasActiveApplication: false,
    pendingApplications: 0,
    approvedApplications: 0,
    loading: true,
  });
  const { profile } = useAuth();

  const fetchApplicationStatus = async () => {
    if (!profile?.id || profile.role !== 'tenant') {
      setStatus({
        hasApprovedApplication: false,
        hasActiveApplication: false,
        pendingApplications: 0,
        approvedApplications: 0,
        loading: false,
      });
      return;
    }

    try {
      const { data: applications, error } = await supabase
        .from('unit_applications')
        .select('id, status')
        .eq('tenant_id', profile.id);

      if (error) throw error;

      const pendingApps = applications?.filter(app => app.status === 'pending') || [];
      const approvedApps = applications?.filter(app => app.status === 'approved') || [];

      setStatus({
        hasApprovedApplication: approvedApps.length > 0,
        hasActiveApplication: (pendingApps.length + approvedApps.length) > 0,
        pendingApplications: pendingApps.length,
        approvedApplications: approvedApps.length,
        loading: false,
      });
    } catch (error) {
      console.error('Error fetching application status:', error);
      setStatus({
        hasApprovedApplication: false,
        hasActiveApplication: false,
        pendingApplications: 0,
        approvedApplications: 0,
        loading: false,
      });
    }
  };

  useEffect(() => {
    fetchApplicationStatus();

    // Set up real-time subscription for application updates
    const channel = supabase
      .channel('application_status_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'unit_applications',
          filter: `tenant_id=eq.${profile?.id}`,
        },
        () => {
          fetchApplicationStatus();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [profile?.id]);

  return status;
};